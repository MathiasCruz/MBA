import ReactCountriesPage from './pages/ReactCountriesPage';

export default function App() {
  return <ReactCountriesPage />;
}
