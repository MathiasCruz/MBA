import { ClipLoader } from 'react-spinners';

export default function Loading() {
  return <ClipLoader />;
}
